from discord.ext import commands

class Ping(commands.Cog):
    def __init__(self, bot):
        self.bot: commands.Bot = bot
    
    @commands.hybrid_command()
    async def ping(self, ctx: commands.Context):
        try:
            await ctx.reply(f"Pong! {self.bot.latency*1000}ms")
        except Exception as e:
            print(e)

async def setup(bot):
    await bot.add_cog(Ping(bot))