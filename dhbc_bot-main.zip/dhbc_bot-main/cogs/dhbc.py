from discord.ext import commands
from os import listdir
from random import choice
from discord import File, Embed
from re import sub
from sqlite3 import connect
from datetime import datetime

def create_dhbc(member, sql, database):
    user = sql.execute(f'SELECT * FROM dhbc WHERE user_id={member.id}').fetchone()
    if user is None:
        sql.execute(f'''INSERT INTO dhbc VALUES ({member.id},0,0,0,2)''')
        database.commit()

def update_points(member, sql, database, amount:int):
    create_dhbc(member, sql, database)
    if amount < 0:
        user_points = sql.execute(f'SELECT point FROM dhbc WHERE user_id = {member.id}').fetchone()
        if (user_points[0] - 1) < 0:
            sql.execute(f"UPDATE dhbc SET point=0 WHERE user_id={member.id}")
            return sql.execute(f"SELECT * FROM dhbc WHERE user_id={member.id}").fetchone()
    sql.execute(f"UPDATE dhbc SET point=point + {amount} WHERE user_id={member.id}")
    database.commit()
    return sql.execute(f"SELECT * FROM dhbc WHERE user_id={member.id}").fetchone()

def update_streak(member, sql, database, amount:int, mode = "ADD"):
    create_dhbc(member, sql, database)
    if mode == "RESET":
        sql.execute(f"UPDATE dhbc SET streak=0 WHERE user_id={member.id}")
        database.commit()
        return sql.execute(f"SELECT * FROM dhbc WHERE user_id={member.id}").fetchone()
    sql.execute(f"UPDATE dhbc SET streak=streak + {amount} WHERE user_id={member.id}")
    database.commit()
    return sql.execute(f"SELECT * FROM dhbc WHERE user_id={member.id}").fetchone()

def update_lost_streak(member, sql, database, amount:int, mode:str = "ADD"):
    create_dhbc(member, sql, database)
    if mode == "RESET":
        sql.execute(f"UPDATE dhbc SET lost_streak=0 WHERE user_id={member.id}")
        database.commit()
        return sql.execute(f"SELECT * FROM dhbc WHERE user_id={member.id}").fetchone()
    sql.execute(f"UPDATE dhbc SET lost_streak=lost_streak + {amount} WHERE user_id={member.id}")
    return sql.execute(f"SELECT * FROM dhbc WHERE user_id={member.id}").fetchone()

def update_try_times(member, sql, database, amount:int, mode = "ADD"):
    create_dhbc(member, sql, database)
    user_try_times = sql.execute(f"SELECT try_times FROM dhbc WHERE user_id={member.id}").fetchone()
    if user_try_times[0] >= 2 and amount <= -1 and mode == "ADD":
        sql.execute(f"UPDATE dhbc SET try_times=try_times + {amount} WHERE user_id={member.id}")
        database.commit()
    elif mode == "RESET":
        sql.execute(f"UPDATE dhbc SET try_times=2 WHERE user_id={member.id}")
        database.commit()
    return sql.execute(f"SELECT * FROM dhbc WHERE user_id={member.id}").fetchone()

class Dhbc(commands.Cog):
    def __init__(self, bot):
        self.bot: commands.Bot = bot
        self.questions = listdir("image/")
        self.questions.sort(key=lambda x: int(x[3:][:-4]))
        self.answers = open("ans.txt", "r", encoding="utf8").read().split("\n")
        self.database = connect("data/dhbc.db", timeout=10)
        self.sql = self.database.cursor()
    
    @commands.hybrid_command()
    async def dhbc(self, ctx: commands.Context):
        try:
            create_dhbc(ctx.author, self.sql, self.database)
            user_data = self.sql.execute(f"SELECT * FROM dhbc WHERE user_id={ctx.author.id}").fetchone()
            question = choice(self.questions)
            position = self.questions.index(question)
            answer = self.answers[position]
            em = Embed(title="CÂU HỎI ĐUỔI HÌNH BẮT CHỮ", description=f"Nếu bạn muốn lấy gợi ý câu hỏi hãy nhập 'gy'\nCâu hỏi của bạn (câu hỏi thứ {position+1}):")
            em.set_image(url=f"attachment://{question}")
            await ctx.reply(embed=em, file=File(f"image/{question}"))
            tries = user_data[4]
            win_points = 2
            
            while not tries <= 0: 
                ans_msg = await self.bot.wait_for("message", check=lambda m: m.author == ctx.author and m.channel == ctx.channel)
                if ans_msg.content.lower() == "gy" and win_points >= 2:
                    clean_ans = answer.lower().strip()
                    hint3 = ""
                    win_points -= 1
                    for i in clean_ans.split(" "):
                        k = sub('[?]', i[0],sub('[aàảãáạăằẳẵắặâầẩẫấậbcdđeèẻẽéẹêềểễếệfghiìỉĩíịjklmnoòỏõóọôồổỗốộơờởỡớợpqrstuùủũúụưừửữứựvwxyỳỷỹýỵz]', '[?]', i), count=1)
                        hint3 += k + " "
                    hint = [f"Số kí tự của từ này là {len(clean_ans.replace(' ', ''))}", f"Từ này là {sub('[aàảãáạăằẳẵắặâầẩẫấậbcdđeèẻẽéẹêềểễếệfghiìỉĩíịjklmnoòỏõóọôồổỗốộơờởỡớợpqrstuùủũúụưừửữứựvwxyỳỷỹýỵz]','[?]',clean_ans)}", f"Từ này là {hint3}"]
                    await ctx.reply(choice(hint))
                elif ans_msg.content.lower() == answer.lower():
                    update_points(ctx.author, self.sql, self.database, win_points)
                    user_data = update_streak(ctx.author, self.sql, self.database, 1)
                    update_lost_streak(ctx.author, self.sql, self.database,1, "RESET")
                    update_try_times(ctx.author, self.sql, self.database,1,"RESET")
                    return await ctx.reply(f"Chúc mừng bạn đã đoán đúng! (+{win_points} points)\nSố điểm hiện có: {user_data[1]}\nStreak: {user_data[2]}")
                else:
                    tries -= 1
                    if tries > 0:
                        await ctx.reply(f"Câu trả lời chưa đúng bạn còn {tries} lần thử")

            update_points(ctx.author, self.sql, self.database, -1)
            user_data = update_lost_streak(ctx.author, self.sql, self.database, 1)
            user_data = update_streak(ctx.author, self.sql, self.database, -1, "RESET")
            await ctx.reply(f"Câu trả lời chưa đúng, bạn đã hết lượt thử(-1 point)\nSố điểm hiện có: {user_data[1]}\nStreak: {user_data[2]}\nSố lần thua liên tục: {user_data[3]}")
            if user_data[3] >= 3:
                await ctx.reply(f"Bạn đã đạt mức thua liên tục 3 lần, Số lần trả lời cho các câu sau sẽ bị giảm đi 1 lần")
                update_try_times(ctx.author, self.sql, self.database, -1)
        except Exception as e:
            print(e)

    @commands.command(aliases=['lb', 'bxh'])
    async def leaderboard(self, ctx: commands.Context,mode = "points", member = None):
        try:
            create_dhbc(ctx.author, self.sql, self.database)
            member = member or ctx.author
            user = self.sql.execute(f"SELECT * FROM dhbc WHERE user_id={member.id}").fetchone()
            all_user = self.sql.execute(f"SELECT * FROM dhbc").fetchall()
            user = all_user.index(user) + 1
            top_user = self.sql.execute(f"SELECT * FROM dhbc").fetchmany(10)
            if mode == "points":
                top_user.sort(reverse=True, key = lambda x: int(x[1]))
            else:
                top_user.sort(reverse=True, key = lambda x: int(x[2]))
            msg = ""
            count = 1
            for i in top_user:
                msg += f"{count}. <@{i[0]}> - {str(i[1]) + ' ' + 'điểm' if mode == 'points' else str(i[2]) + ' ' + 'streak'}\n"
                count += 1
            msg += f"\nThứ hạng hiện tại của bạn: {user}"
            em = Embed(title=f"Bảng xếp hạng đuổi hình bắt chữ theo {'điểm' if mode == 'points' else 'streak'}", description=msg, timestamp=datetime.now())
            em.set_author(name = ctx.author.name, icon_url = ctx.author.display_avatar.url)
            await ctx.reply(embed=em)
        except Exception as e:
            print(e)

async def setup(bot):
    await bot.add_cog(Dhbc(bot))