from discord.ext import commands
from os import listdir
from asyncio import run as run_main
import discord
import json
import sqlite3

# TOKEN="OTkwOTA3MDUxNDYwOTIzNDAz.G_l4xI.rQ7ykLxGr0zJowZ91bgHBA-igQcK0FIT9xuWEI"
TOKEN = "OTkwOTA3MDUxNDYwOTIzNDAz.GNi0r9.Eh20lslfOepxNy2eT3-z-L1IPRqsgh2GlsymbY"

bot = commands.Bot(command_prefix='-', intents=discord.Intents.all())
# bot.conn = sqlite3.connect("data/dhbc.db", timeout=10)
# bot.sql = bot.conn.cursor()
# print(bot.sql.execute("SELECT * FROM dhbc").fetchall())
def isadmin(author):
    try:
        config= json.load(open("config.json","r"))
        if config["admin_id"] in [i.id for i in author.roles]: 
            return True
        return False
    except Exception as e:
        print(e)
    
def save_data(file,data):
    try:
        with open(file, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(e)
        
def get_data(file):
    with open(file, 'r', encoding="utf8") as f:
        users = json.load(f)
    return users

@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"Logged in as {bot.user}")
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name="a song"))

async def main():
    for file in listdir('./cogs'):
        if file.endswith('.py'):
            try:
                await bot.load_extension(f'cogs.{file[:-3]}')
                print(f'Loaded {file}')
            except Exception as e:
                print(f'Failed to load {file}: {e}')
    await bot.start(TOKEN)
if __name__ == '__main__':
    run_main(main())
